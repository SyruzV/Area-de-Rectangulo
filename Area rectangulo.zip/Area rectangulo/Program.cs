﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreadeRectangulo
{

    class Progam
    {

        static void Main(string[] args)
        {
            //Calcular el area
            Console.Write("Ingrese la base del rectangulo: ");
            int base_r = int.Parse(Console.ReadLine());
            Console.Write("Ingrese la latura del rectangulo" );
            int altura = int.Parse(Console.ReadLine());
            double area = base_r * altura;
            Console.Write("El area del rectangulo es: " + area + "cm");
            Console.ReadKey();
        }
    }
}


